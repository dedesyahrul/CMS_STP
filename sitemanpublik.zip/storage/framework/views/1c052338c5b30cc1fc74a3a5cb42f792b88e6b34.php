<div>
    <span class="font-semibold">Show entries:</span>
    <select wire:model="entries" class="form-select rounded-md border-gray-300">
        <?php $__currentLoopData = $showEntriesOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option><?php echo e($option); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>
<?php /**PATH C:\Users\ROG\Documents\Laravel\port\resources\views/livewire/show-entries-dropdown.blade.php ENDPATH**/ ?>