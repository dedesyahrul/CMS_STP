<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Educations')); ?>

        </h2>
        <a href="<?php echo e(route('educations.create')); ?>" class="btn btn-primary">Add Education</a>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg p-6">
                <h3 class="text-lg font-bold mb-4">List of Educations</h3>

                <?php if($educations->isEmpty()): ?>
                    <p>No educations found.</p>
                <?php else: ?>
                    <ul>
                        <?php $__currentLoopData = $educations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $education): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>
                                <h4 class="text-lg font-bold"><?php echo e($education->institution); ?></h4>
                                <p><?php echo e($education->degree); ?></p>
                                <p><?php echo e($education->major); ?></p>
                                
                                <p><?php echo e($education->start_year->format('Y')); ?> - <?php echo e($education->end_year ? $education->end_year->format('Y') : 'Present'); ?></p>
                                <div>
                                    <a href="<?php echo e(route('educations.edit', $education)); ?>" class="text-blue-600">Edit</a>
                                    <form action="<?php echo e(route('educations.destroy', $education)); ?>" method="POST" class="inline">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="text-red-600">Delete</button>
                                    </form>
                                </div>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                <?php endif; ?>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\Users\Dede Syahrul\Documents\Laravel\Laravel\port\resources\views/educations/index.blade.php ENDPATH**/ ?>