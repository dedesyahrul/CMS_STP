<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Profiles')); ?>

        </h2>
        <a href="<?php echo e(route('profiles.create')); ?>" class="btn btn-primary">Add Profile</a>


     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg p-6">
                <h3 class="text-lg font-bold mb-4">List of Profiles</h3>

                <?php if($profiles->isEmpty()): ?>
                    <p>No profiles found.</p>
                <?php else: ?>
                    <ul>
                        <?php $__currentLoopData = $profiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>
                                <h4 class="text-lg font-bold"><?php echo e($profile->user->name); ?></h4>
                                <p class="text-gray-600"><?php echo e($profile->address); ?></p>
                                <p class="text-gray-600"><?php echo e($profile->phone); ?></p>

                                <?php if($profile->profile_image): ?>
                                    <img src="<?php echo e(asset('images/' . $profile->profile_image)); ?>" alt="Profile Image" class="w-24 h-24 rounded-full">
                                <?php else: ?>
                                    <span class="text-gray-500">No profile image available</span>
                                <?php endif; ?>

                                <a href="<?php echo e(route('profiles.edit', $profile)); ?>" class="text-blue-600">Edit</a>

                                <form action="<?php echo e(route('profiles.destroy', $profile)); ?>" method="POST" onsubmit="return confirm('Are you sure you want to delete this profile?')">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="text-red-600 ml-2">Delete</button>
                                </form>


                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                <?php endif; ?>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\Users\ROG\Documents\Laravel\port\resources\views/profiles/index.blade.php ENDPATH**/ ?>