<?php return array (
  'api-token-manager' => 'App\\Http\\Livewire\\ApiTokenManager',
  'kelola-bantuan-hukum' => 'App\\Http\\Livewire\\KelolaBantuanHukum',
  'navigation-menu-beranda' => 'App\\Http\\Livewire\\NavigationMenuBeranda',
  'show-entries-dropdown' => 'App\\Http\\Livewire\\ShowEntriesDropdown',
);