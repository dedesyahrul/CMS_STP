<?php

namespace App\Http\Livewire;

use Livewire\Component;

use App\Models\User;
use Illuminate\Support\Facades\Auth;

class ApiTokenManager extends Component
{
    public $user;
    public $plainTextToken;

    public function mount()
    {
        $this->user = Auth::user();
        $this->plainTextToken = 'Contoh nilai plainTextToken'; // Ganti dengan nilai sesuai kebutuhan Anda
    }

    public function render()
    {
        return view('livewire.api-token-manager');
    }

}
