<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ApiTokenController extends Controller
{
    /**
     * Display the API tokens index page.
     *
     * @return \Illuminate\View\View
     */
    public function index()
    {
        // Lakukan logika yang diperlukan untuk menampilkan halaman indeks API Tokens
        // Misalnya, dapatkan daftar token dari database atau sumber lainnya

        // Contoh data token untuk ditampilkan pada halaman
        $tokens = [
            [
                'id' => 1,
                'name' => 'Token 1',
                'created_at' => '2023-06-21 10:00:00',
            ],
            [
                'id' => 2,
                'name' => 'Token 2',
                'created_at' => '2023-06-22 15:30:00',
            ],
        ];

        // Kirim data token ke view
        return view('api.index', compact('tokens'));
    }
}
